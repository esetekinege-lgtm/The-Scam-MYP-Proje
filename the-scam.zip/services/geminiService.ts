
import { GoogleGenAI, Type } from "@google/genai";
import { EmailType, Email } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || "" });

export async function generateDynamicEmails(level: number, season: number): Promise<Email[]> {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Generate 4 realistic Turkish email objects for a game. 
      Season: ${season}. Level: ${level}.
      Difficulty characteristics:
      Season 1: Obvious clickbait vs official.
      Season 2: Typos in domains (e.g., netfIix instead of netflix).
      Season 3: Highly professional and personalized tone.
      
      Mix: 2 SAFE, 2 PHISHING.
      SAFE should give $1000. PHISHING should increase danger bar.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              id: { type: Type.STRING },
              sender: { type: Type.STRING },
              subject: { type: Type.STRING },
              content: { type: Type.STRING },
              type: { type: Type.STRING, enum: ["SAFE", "PHISHING"] },
              icon: { type: Type.STRING },
            },
            required: ["id", "sender", "subject", "content", "type", "icon"]
          }
        }
      }
    });

    if (response.text) {
      const emails = JSON.parse(response.text);
      return emails.map((e: any) => ({ ...e, isRead: false }));
    }
  } catch (error) {
    console.error("Gemini Error:", error);
  }
  
  return [];
}
