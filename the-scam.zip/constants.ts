
import { EmailType, Email } from './types';

export const INITIAL_EMAILS: Email[] = [
  {
    id: '1',
    sender: 'Doğalgaz A.Ş.',
    subject: 'Fatura Ödeme Hatırlatması',
    content: 'Sayın abonemiz, 2024 Mart ayı faturanız oluşturulmuştur. Son ödeme tarihi: 15.04.2024.',
    type: EmailType.SAFE,
    icon: '📄',
    isRead: false
  },
  {
    id: '2',
    sender: 'Apple Inc.',
    subject: 'TEBRİKLER! iPhone 15 Kazandınız!',
    content: 'Şanslı kullanıcımız seçildiniz. Hemen tıkla ve iPhone 15 Pro Max ödülünü talep et!',
    type: EmailType.PHISHING,
    icon: '🎁',
    isRead: false
  },
  {
    id: '3',
    sender: 'E-Devlet Kapısı',
    subject: 'Vergi İadesi Bilgilendirmesi',
    content: '2023 yılına ait vergi iadeniz onaylanmıştır. Detaylar için resmi portalı ziyaret edin (turkiye.gov.tr).',
    type: EmailType.SAFE,
    icon: '🏛️',
    isRead: false
  }
];

export const UPGRADES_LIST = [
  {
    id: 'doorChain',
    name: 'Kapı Zinciri',
    description: 'Dolandırıcı içeri girmeye çalıştığında sana ekstra zaman kazandırır.',
    cost: 2000,
    maxLevel: 3
  },
  {
    id: 'antivirus',
    name: 'Antivirüs Filtresi',
    description: 'Clickbait kelimelerin altını hafifçe çizer (İpucu verir).',
    cost: 3500,
    maxLevel: 1
  },
  {
    id: 'shutters',
    name: 'Pencere Panjuru',
    description: 'Dolandırıcının yaklaşma görselini gizler, korkuyu azaltır.',
    cost: 1500,
    maxLevel: 1
  },
  {
    id: 'siren',
    name: 'Siren Sistemi',
    description: 'Hata yaptığında barın %10\'unu temizler (Tur başına 1 kez).',
    cost: 5000,
    maxLevel: 1
  }
];
