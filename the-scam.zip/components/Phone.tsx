
import React from 'react';
import { Email, EmailType } from '../types';

interface PhoneProps {
  balance: number;
  lives: number;
  emails: Email[];
  onEmailClick: (email: Email) => void;
  onSkipLevel: () => void;
  hasAntivirus: boolean;
  isGlitching: boolean;
}

const Phone: React.FC<PhoneProps> = ({ 
  balance, 
  lives, 
  emails, 
  onEmailClick, 
  onSkipLevel,
  hasAntivirus,
  isGlitching 
}) => {
  const allRead = emails.length > 0 && emails.every(e => e.isRead);

  return (
    <div className={`w-full h-full phone-gradient flex flex-col p-4 font-sans relative ${isGlitching ? 'glitch' : ''}`}>
      {/* Top Bar */}
      <div className="flex justify-between items-center mb-6 text-white border-b border-slate-700 pb-2">
        <div className="flex flex-col">
          <span className="text-[10px] text-slate-400 uppercase">Bakiye</span>
          <span className="text-xl font-bold text-green-400">${balance.toLocaleString()}</span>
        </div>
        <div className="flex flex-col items-end">
          <span className="text-[10px] text-slate-400 uppercase">Kalan Hak</span>
          <div className="flex gap-1">
            {[...Array(3)].map((_, i) => (
              <div 
                key={i} 
                className={`w-3 h-3 rounded-full border border-slate-500 ${i < lives ? 'bg-red-500 shadow-[0_0_5px_#ef4444]' : 'bg-slate-800'}`}
              ></div>
            ))}
          </div>
        </div>
      </div>

      {/* Inbox Title */}
      <div className="flex justify-between items-center mb-3">
        <h2 className="text-slate-200 text-sm font-bold flex items-center gap-2">
          <span className="bg-blue-500 text-[10px] px-1 rounded text-white">{emails.filter(e => !e.isRead).length}</span> 
          Gelen Kutusu
        </h2>
      </div>

      {/* Email List */}
      <div className="flex-1 overflow-y-auto flex flex-col gap-2 no-scrollbar mb-4">
        {emails.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full opacity-30 text-white italic">
            <span>Mesaj bulunamadı...</span>
          </div>
        ) : (
          emails.map((email) => (
            <button
              key={email.id}
              onClick={() => onEmailClick(email)}
              disabled={email.isRead}
              className={`text-left p-3 rounded-lg border-2 transition-all transform hover:scale-[1.02] active:scale-95 ${
                email.isRead 
                  ? 'bg-slate-800 border-slate-700 opacity-50 grayscale' 
                  : 'bg-slate-700 border-slate-600 hover:border-blue-400'
              }`}
            >
              <div className="flex gap-3 items-start">
                <span className="text-2xl">{email.icon}</span>
                <div className="flex-1 overflow-hidden">
                  <h3 className="text-blue-300 text-[10px] font-bold truncate">
                    {email.sender}
                  </h3>
                  <p className={`text-white text-[11px] font-medium leading-tight mt-1 ${
                    hasAntivirus && email.type === EmailType.PHISHING && email.subject.toLowerCase().includes('kazandınız') 
                    ? 'underline decoration-red-500 decoration-wavy' 
                    : ''
                  }`}>
                    {email.subject}
                  </p>
                </div>
              </div>
            </button>
          ))
        )}
      </div>

      {/* Bölümü Geç Button */}
      <button
        onClick={onSkipLevel}
        className={`w-full py-4 border-4 transition-all text-xl font-bold uppercase tracking-wider mb-2 ${
          allRead 
          ? 'bg-green-600 border-green-400 text-white hover:bg-green-500 shadow-[0_0_15px_rgba(34,197,94,0.4)]' 
          : 'bg-slate-800 border-slate-700 text-slate-500 hover:bg-slate-700 hover:text-slate-400'
        }`}
      >
        Bölümü Geç
      </button>

      {/* Glitch Overlay */}
      {isGlitching && (
        <div className="absolute inset-0 bg-red-900/40 z-50 flex items-center justify-center">
          <div className="text-center">
            <h1 className="text-white text-5xl font-black italic tracking-tighter neon-glow animate-ping mb-4">HACKED</h1>
            <p className="text-red-400 text-sm font-mono">SİSTEM KRİTİK!</p>
          </div>
        </div>
      )}

      {/* Home Button Mockup */}
      <div className="flex justify-center">
        <div className="w-12 h-1 bg-slate-700 rounded-full"></div>
      </div>
    </div>
  );
};

export default Phone;
