
import React from 'react';

interface HouseProps {
  reachProgress: number;
  hasShutters: boolean;
}

const House: React.FC<HouseProps> = ({ reachProgress, hasShutters }) => {
  // Scammer visibility and intensity based on reachProgress
  const scammerVisible = reachProgress > 10;
  const intensity = reachProgress / 100;

  return (
    <div className="relative w-full h-full bg-[#1e2335] overflow-hidden flex flex-col items-center justify-end border-r-4 border-black">
      {/* Wall Texture/Shadows */}
      <div className="absolute inset-0 bg-gradient-to-b from-[#0a0c1a] to-[#1a1f2e] opacity-80"></div>
      
      {/* Scammer Progress Bar (Top) */}
      <div className="absolute top-10 w-full flex flex-col items-center z-[100]">
        <div className="w-[85%] h-8 bg-black border-2 border-red-900 overflow-hidden shadow-[0_0_15px_rgba(0,0,0,0.5)]">
          <div 
            className="h-full bg-red-600 shadow-[0_0_20px_#ff0000] transition-all duration-700 ease-in-out"
            style={{ width: `${reachProgress}%` }}
          />
        </div>
        <div className="mt-3 text-red-500 text-2xl uppercase tracking-[0.4em] font-bold neon-glow">
          DOLANDIRICININ ERİŞİMİ
        </div>
      </div>

      {/* Main Room Layout */}
      <div className="relative w-full h-full flex items-center justify-center pt-20">
        
        {/* Floor */}
        <div className="absolute bottom-0 w-full h-1/4 bg-[#121421] border-t-4 border-black/20">
          <div className="w-full h-full opacity-10" style={{ backgroundImage: 'repeating-linear-gradient(90deg, transparent, transparent 40px, #000 40px, #000 42px)' }}></div>
        </div>

        {/* Left Furniture: Table, Lamp, Armchair */}
        <div className="absolute bottom-1/4 left-8 z-20 flex items-end">
          {/* Side Table */}
          <div className="relative w-24 h-20 mb-[-10px]">
            <div className="absolute top-0 w-full h-4 bg-[#3d2b1f] border-2 border-black rounded-full"></div>
            <div className="absolute top-4 left-1/2 -translate-x-1/2 w-4 h-16 bg-[#2a1d15] border-x-2 border-black"></div>
            <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-16 h-4 bg-[#2a1d15] border-2 border-black rounded-t-lg"></div>
            
            {/* Lamp */}
            <div className="absolute -top-14 left-1/2 -translate-x-1/2 w-12 h-16 flex flex-col items-center">
              <div className="w-8 h-10 bg-yellow-400/90 border-2 border-black rounded-t-full shadow-[0_0_30px_rgba(250,204,21,0.4)]"></div>
              <div className="w-10 h-2 bg-[#1a1a1a] border-x-2 border-b-2 border-black"></div>
              {/* Lamp Glow */}
              <div className="absolute -top-4 w-32 h-32 bg-yellow-400/10 rounded-full blur-2xl pointer-events-none"></div>
            </div>
          </div>

          {/* Armchair */}
          <div className="w-40 h-44 bg-[#2d3a31] border-4 border-black rounded-t-3xl relative ml-4 shadow-2xl">
            <div className="absolute -left-4 bottom-0 w-10 h-28 bg-[#232e27] border-4 border-black rounded-3xl"></div>
            <div className="absolute -right-4 bottom-0 w-10 h-28 bg-[#232e27] border-4 border-black rounded-3xl"></div>
            <div className="absolute top-1/2 left-4 right-4 h-1/2 bg-[#38493d] border-t-2 border-black/20"></div>
          </div>
        </div>

        {/* Center Door */}
        <div className="relative w-44 h-72 bg-[#2d1e15] border-x-8 border-t-8 border-[#3d2b1f] shadow-[0_0_50px_rgba(0,0,0,0.5)] z-10 flex flex-col items-center">
          {/* Scratches/Marks on door */}
          <div className="absolute inset-0 opacity-20 pointer-events-none">
             <div className="absolute top-10 left-4 w-12 h-[2px] bg-black rotate-45"></div>
             <div className="absolute top-12 left-6 w-8 h-[2px] bg-black -rotate-12"></div>
             <div className="absolute bottom-20 right-8 w-16 h-[2px] bg-black rotate-[120deg]"></div>
          </div>
          <div className="w-32 h-24 border-4 border-black/30 mt-10 shadow-inner"></div>
          <div className="w-32 h-24 border-4 border-black/30 mt-6 shadow-inner"></div>
          <div className="absolute top-1/2 right-6 w-6 h-6 bg-[#1a1a1a] rounded-full border-4 border-black"></div>
          
          {/* Danger Glow around door */}
          {reachProgress > 80 && (
            <div className="absolute inset-0 border-4 border-red-600/30 animate-pulse"></div>
          )}
        </div>

        {/* Right Furniture: Plant, Bookshelf */}
        <div className="absolute bottom-1/4 right-8 z-20 flex items-end">
          {/* Potted Plant */}
          <div className="relative mr-8">
            <div className="w-20 h-20 bg-[#2d4a35] flex flex-col items-center justify-end">
               {/* Leaves */}
               <div className="w-24 h-24 bg-[#3a5a40] rounded-full absolute -top-16 -left-2 border-2 border-black/20"></div>
               <div className="w-20 h-20 bg-[#4f772d] rounded-full absolute -top-20 right-0 border-2 border-black/20"></div>
            </div>
            {/* Pot */}
            <div className="w-24 h-16 bg-[#4e342e] border-x-4 border-b-4 border-black rounded-b-xl relative">
              <div className="absolute -top-2 -left-1 w-[calc(100%+8px)] h-4 bg-[#5d4037] border-2 border-black"></div>
            </div>
          </div>

          {/* Bookshelf */}
          <div className="w-36 h-80 bg-[#1a120b] border-x-4 border-t-4 border-black flex flex-col justify-evenly p-2 shadow-2xl">
             {[1,2,3,4,5].map(i => (
               <div key={i} className="w-full h-10 border-b-2 border-black/50 flex gap-1 items-end px-1 overflow-hidden">
                  <div className="w-3 h-8 bg-blue-900/50"></div>
                  <div className="w-2 h-6 bg-red-900/50"></div>
                  <div className="w-4 h-9 bg-green-900/50"></div>
               </div>
             ))}
          </div>
        </div>

        {/* Windows */}
        {/* Left Window */}
        <div className="absolute top-24 left-[15%] w-36 h-56 bg-[#0c0c14] border-4 border-black overflow-hidden z-0">
          {/* Curtains */}
          <div className="absolute inset-0 z-20 flex justify-between pointer-events-none">
            <div className="w-8 h-full bg-[#1a1a1a] border-r-2 border-black/50"></div>
            <div className="w-8 h-full bg-[#1a1a1a] border-l-2 border-black/50"></div>
          </div>
          {/* Outdoor Danger Glow */}
          <div 
            className="absolute inset-0 transition-colors duration-500"
            style={{ backgroundColor: `rgba(185, 28, 28, ${intensity * 0.4})` }}
          />
          {/* Scammer Silhouette */}
          {scammerVisible && !hasShutters && (
            <div 
              className="absolute left-1/2 -translate-x-1/2 bottom-0 w-24 h-48 bg-black rounded-t-full transition-all duration-300"
              style={{ 
                transform: `scale(${0.8 + intensity * 0.6}) translateY(${(1 - intensity) * 20}px)`,
                opacity: intensity + 0.2
              }}
            >
              <div className="absolute top-12 left-6 w-3 h-3 bg-red-600 rounded-full shadow-[0_0_15px_#ff0000]"></div>
              <div className="absolute top-12 right-6 w-3 h-3 bg-red-600 rounded-full shadow-[0_0_15px_#ff0000]"></div>
            </div>
          )}
          {/* Panes */}
          <div className="absolute inset-0 z-10 grid grid-cols-2 grid-rows-2 border-2 border-black/40 pointer-events-none">
            <div className="border-r border-b border-black/20"></div>
            <div className="border-b border-black/20"></div>
            <div className="border-r border-black/20"></div>
            <div></div>
          </div>
          {hasShutters && <div className="absolute inset-0 bg-slate-950 z-30 flex flex-col justify-evenly">
             {[...Array(8)].map((_, i) => <div key={i} className="w-full h-2 bg-slate-800 border-b border-black/50"></div>)}
          </div>}
        </div>

        {/* Right Window */}
        <div className="absolute top-24 right-[15%] w-36 h-56 bg-[#0c0c14] border-4 border-black overflow-hidden z-0">
          {/* Curtains */}
          <div className="absolute inset-0 z-20 flex justify-between pointer-events-none">
            <div className="w-8 h-full bg-[#1a1a1a] border-r-2 border-black/50"></div>
            <div className="w-8 h-full bg-[#1a1a1a] border-l-2 border-black/50"></div>
          </div>
          {/* Outdoor Danger Glow */}
          <div 
            className="absolute inset-0 transition-colors duration-500"
            style={{ backgroundColor: `rgba(185, 28, 28, ${intensity * 0.4})` }}
          />
          {/* Panes */}
          <div className="absolute inset-0 z-10 grid grid-cols-2 grid-rows-2 border-2 border-black/40 pointer-events-none">
            <div className="border-r border-b border-black/20"></div>
            <div className="border-b border-black/20"></div>
            <div className="border-r border-black/20"></div>
            <div></div>
          </div>
          {hasShutters && <div className="absolute inset-0 bg-slate-950 z-30 flex flex-col justify-evenly">
             {[...Array(8)].map((_, i) => <div key={i} className="w-full h-2 bg-slate-800 border-b border-black/50"></div>)}
          </div>}
        </div>

      </div>

      {/* Retro Scanline Overlay */}
      <div className="pointer-events-none absolute inset-0 z-[200] opacity-[0.05] bg-[linear-gradient(rgba(18,16,16,0)_50%,rgba(0,0,0,0.25)_50%),linear-gradient(90deg,rgba(255,0,0,0.06),rgba(0,255,0,0.02),rgba(0,0,255,0.06))] bg-[length:100%_4px,3px_100%]"></div>
    </div>
  );
};

export default House;
