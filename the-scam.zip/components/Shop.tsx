
import React from 'react';
import { Upgrade, GameState } from '../types';
import { UPGRADES_LIST } from '../constants';

interface ShopProps {
  gameState: GameState;
  onPurchase: (upgradeId: string) => void;
  onNextLevel: () => void;
}

const Shop: React.FC<ShopProps> = ({ gameState, onPurchase, onNextLevel }) => {
  return (
    <div className="fixed inset-0 bg-black/90 z-[100] flex items-center justify-center p-8">
      <div className="bg-slate-900 border-4 border-slate-700 w-full max-w-2xl p-8 pixel-border">
        <div className="flex justify-between items-center mb-8 border-b-4 border-slate-800 pb-4">
          <h2 className="text-4xl text-blue-400 font-bold uppercase tracking-widest">YÜKSELTME MERKEZİ</h2>
          <div className="text-right">
            <div className="text-slate-400 text-sm uppercase">Mevcut Bakiye</div>
            <div className="text-3xl text-green-400 font-bold">${gameState.balance.toLocaleString()}</div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          {UPGRADES_LIST.map((upgrade) => {
            const currentLevel = (gameState.upgrades as any)[upgrade.id] || 0;
            const isMax = currentLevel >= upgrade.maxLevel;
            const canAfford = gameState.balance >= upgrade.cost;

            return (
              <div key={upgrade.id} className="bg-slate-800 p-4 border-2 border-slate-700 flex flex-col">
                <div className="flex justify-between items-start mb-2">
                  <h3 className="text-xl text-white font-bold">{upgrade.name}</h3>
                  <span className="text-blue-400 text-sm">Seviye: {currentLevel}/{upgrade.maxLevel}</span>
                </div>
                <p className="text-slate-400 text-xs mb-4 flex-1">{upgrade.description}</p>
                <button
                  disabled={isMax || !canAfford}
                  onClick={() => onPurchase(upgrade.id)}
                  className={`py-2 px-4 text-center font-bold text-sm transition-all ${
                    isMax 
                      ? 'bg-slate-700 text-slate-500 cursor-not-allowed'
                      : canAfford 
                        ? 'bg-blue-600 hover:bg-blue-500 text-white cursor-pointer'
                        : 'bg-red-900 text-red-300 cursor-not-allowed'
                  }`}
                >
                  {isMax ? 'MAX' : `$${upgrade.cost.toLocaleString()}`}
                </button>
              </div>
            );
          })}
        </div>

        <button
          onClick={onNextLevel}
          className="w-full bg-green-600 hover:bg-green-500 text-white py-4 text-2xl font-black uppercase tracking-widest transition-transform hover:scale-[1.02]"
        >
          SIRADAKİ GÜN &gt;&gt;
        </button>
      </div>
    </div>
  );
};

export default Shop;
