
import React, { useState, useEffect } from 'react';
import House from './components/House';
import Phone from './components/Phone';
import Shop from './components/Shop';
import { GameState, Email, EmailType, GameScreen } from './types';
import { INITIAL_EMAILS, UPGRADES_LIST } from './constants';
import { generateDynamicEmails } from './services/geminiService';

const App: React.FC = () => {
  const [gameState, setGameState] = useState<GameState>({
    screen: GameScreen.MENU,
    isLoading: false,
    balance: 0,
    reachProgress: 0,
    lives: 3,
    currentLevel: 1,
    selectedSeason: 1,
    emails: INITIAL_EMAILS,
    upgrades: {
      doorChain: 0,
      antivirus: 0,
      shutters: 0,
      siren: 0
    },
    isGameOver: false,
    isVictory: false,
    showShop: false,
    lastActionMessage: 'Gelen kutunu kontrol et ve tehlikelerden korun.'
  });

  const [isGlitching, setIsGlitching] = useState(false);
  const [sirenUsedThisLevel, setSirenUsedThisLevel] = useState(false);

  useEffect(() => {
    if (gameState.screen === GameScreen.GAME) {
      if (gameState.reachProgress >= 100 || gameState.lives <= 0) {
        setGameState(prev => ({ ...prev, isGameOver: true }));
      }
    }
  }, [gameState.reachProgress, gameState.lives, gameState.screen]);

  const handleEmailClick = (email: Email) => {
    if (email.isRead) return;

    const newEmails = gameState.emails.map(e => 
      e.id === email.id ? { ...e, isRead: true } : e
    );

    if (email.type === EmailType.SAFE) {
      setGameState(prev => ({
        ...prev,
        balance: prev.balance + 1000,
        emails: newEmails,
        lastActionMessage: 'Güvenli mail: +$1,000 kazandın!'
      }));
    } else {
      setIsGlitching(true);
      setTimeout(() => setIsGlitching(false), 1500);

      const baseIncrease = gameState.currentLevel <= 5 ? 33 : (gameState.currentLevel <= 10 ? 40 : 50);
      let sirenReduction = 0;
      if (gameState.upgrades.siren > 0 && !sirenUsedThisLevel) {
        sirenReduction = 10;
        setSirenUsedThisLevel(true);
      }

      setGameState(prev => ({
        ...prev,
        lives: prev.lives - 1,
        reachProgress: Math.min(100, Math.max(0, prev.reachProgress + baseIncrease - sirenReduction)),
        emails: newEmails,
        lastActionMessage: 'TUZAĞA DÜŞTÜN! Dolandırıcı yaklaşıyor!'
      }));
    }
  };

  const handleSkipLevel = () => {
    setGameState(prev => ({ ...prev, showShop: true }));
  };

  const handlePurchase = (upgradeId: string) => {
    const upgrade = UPGRADES_LIST.find(u => u.id === upgradeId);
    if (!upgrade || gameState.balance < upgrade.cost) return;

    setGameState(prev => ({
      ...prev,
      balance: prev.balance - upgrade.cost,
      upgrades: {
        ...prev.upgrades,
        [upgradeId]: (prev.upgrades as any)[upgradeId] + 1
      },
      lastActionMessage: `${upgrade.name} satın alındı!`
    }));
  };

  const startNextLevel = async () => {
    setGameState(prev => ({ ...prev, isLoading: true }));
    try {
      const nextLevel = gameState.currentLevel + 1;
      setSirenUsedThisLevel(false);
      const newEmails = await generateDynamicEmails(nextLevel, gameState.selectedSeason);
      setGameState(prev => ({
        ...prev,
        isLoading: false,
        currentLevel: nextLevel,
        emails: newEmails.length > 0 ? newEmails : INITIAL_EMAILS,
        showShop: false,
        lastActionMessage: `${nextLevel}. GÜN başladı. Dikkatli ol.`
      }));
    } catch (e) {
      setGameState(prev => ({ ...prev, isLoading: false }));
    }
  };

  const selectSeason = async (season: number) => {
    setGameState(prev => ({ ...prev, isLoading: true }));
    try {
      const emails = await generateDynamicEmails(1, season);
      setGameState(prev => ({
        ...prev,
        isLoading: false,
        selectedSeason: season,
        emails: emails.length > 0 ? emails : INITIAL_EMAILS,
        screen: GameScreen.LEVEL_INTRO,
        // Reset everything for fresh season start
        balance: 0,
        reachProgress: 0,
        lives: 3,
        currentLevel: 1,
        upgrades: { doorChain: 0, antivirus: 0, shutters: 0, siren: 0 },
        isGameOver: false,
        lastActionMessage: 'Yeni sezon başladı. Dikkatli ol.'
      }));
    } catch (e) {
      setGameState(prev => ({ ...prev, isLoading: false }));
    }
  };

  const restartSeason = async () => {
    await selectSeason(gameState.selectedSeason);
  };

  const startGame = () => {
    setGameState(prev => ({ ...prev, screen: GameScreen.GAME }));
  };

  if (gameState.isLoading) {
    return (
      <div className="w-full h-full bg-black flex flex-col items-center justify-center p-8">
        <div className="text-white text-5xl font-black italic tracking-widest animate-pulse mb-8">
          YÜKLENİYOR...
        </div>
        <div className="w-64 h-4 bg-slate-900 border-2 border-slate-700 p-1">
          <div className="h-full bg-blue-600 animate-[loading-bar_2s_infinite]"></div>
        </div>
        <style>{`
          @keyframes loading-bar {
            0% { width: 0%; }
            50% { width: 100%; }
            100% { width: 0%; }
          }
        `}</style>
      </div>
    );
  }

  if (gameState.screen === GameScreen.MENU) {
    return (
      <div className="w-full h-full bg-[#1a2135] relative flex flex-col items-center justify-center overflow-hidden">
        {/* Sky Background Gradient */}
        <div className="absolute inset-0 bg-gradient-to-b from-[#0a0c1a] via-[#1a2135] to-[#2a344a]"></div>

        {/* The House - Full Screen composition */}
        <div className="relative w-full h-full flex flex-col items-center justify-center pt-24">
          
          {/* Main House Box */}
          <div className="relative w-[800px] h-[550px] bg-[#3b4760] border-x-[10px] border-[#0f172a] flex flex-col items-center justify-end z-10 overflow-visible">
            
            {/* Siding lines */}
            <div className="absolute inset-0 pointer-events-none opacity-20">
              {Array.from({ length: 20 }).map((_, i) => (
                <div key={i} className="w-full h-[1px] bg-black" style={{ top: `${i * 28}px` }}></div>
              ))}
            </div>

            {/* Roof - Large pixelated triangle */}
            <div className="absolute -top-[180px] w-[108%] h-[180px] bg-[#2a344a] border-t-4 border-l-4 border-r-4 border-[#0f172a]" 
                 style={{ clipPath: 'polygon(50% 0%, 0% 100%, 100% 100%)' }}>
            </div>

            {/* Title & Play Button Group - Positioned together at the top of the house body */}
            <div className="absolute -top-32 w-full flex flex-col items-center z-50 gap-8 pointer-events-none">
               <h1 className="text-[160px] leading-none text-white font-black italic tracking-tighter drop-shadow-[0_0_20px_rgba(255,255,255,0.4)] glitch" 
                   style={{ WebkitTextStroke: '6px #ef4444' }}>
                 THE SCAM
               </h1>
               <div className="pointer-events-auto">
                <button 
                  onClick={() => setGameState(prev => ({ ...prev, screen: GameScreen.SEASON_SELECT }))}
                  className="bg-[#22d3ee] text-white px-20 py-4 text-6xl font-black border-4 border-[#06b6d4] hover:bg-[#06b6d4] transition-all transform hover:scale-105 active:scale-95 pixel-border shadow-[0_0_30px_rgba(34,211,238,0.7)] uppercase"
                >
                  OYNA
                </button>
               </div>
            </div>

            {/* Windows with Silhouettes */}
            <div className="absolute top-32 left-16 w-44 h-64 bg-[#12121e] border-4 border-[#0f172a] flex items-center justify-center overflow-hidden">
               {/* Pane Dividers */}
               <div className="absolute inset-0 flex border-black/30">
                  <div className="w-1/2 h-full border-r-2 border-black/40"></div>
                  <div className="w-full h-1/2 absolute top-1/2 border-t-2 border-black/40"></div>
               </div>
               {/* Scammer Silhouette with Red Eyes */}
               <div className="w-28 h-48 bg-black rounded-t-full relative translate-y-12">
                  <div className="absolute top-12 left-8 w-3 h-3 bg-red-600 rounded-full shadow-[0_0_12px_#ff0000]"></div>
                  <div className="absolute top-12 right-8 w-3 h-3 bg-red-600 rounded-full shadow-[0_0_12px_#ff0000]"></div>
               </div>
            </div>

            <div className="absolute top-32 right-16 w-44 h-64 bg-[#12121e] border-4 border-[#0f172a] flex items-center justify-center overflow-hidden">
               {/* Pane Dividers */}
               <div className="absolute inset-0 flex border-black/30">
                  <div className="w-1/2 h-full border-r-2 border-black/40"></div>
                  <div className="w-full h-1/2 absolute top-1/2 border-t-2 border-black/40"></div>
               </div>
               {/* Scammer Silhouette with Red Eyes */}
               <div className="w-28 h-48 bg-black rounded-t-full relative translate-y-12">
                  <div className="absolute top-12 left-8 w-3 h-3 bg-red-600 rounded-full shadow-[0_0_12px_#ff0000]"></div>
                  <div className="absolute top-12 right-8 w-3 h-3 bg-red-600 rounded-full shadow-[0_0_12px_#ff0000]"></div>
               </div>
            </div>

            {/* Door */}
            <div className="w-48 h-[250px] bg-[#2a1b0e] border-x-[6px] border-t-[6px] border-[#0f172a] mx-auto relative flex flex-col items-center">
               <div className="w-32 h-24 border-4 border-black/20 mt-8"></div>
               <div className="w-32 h-24 border-4 border-black/20 mt-4"></div>
               <div className="absolute top-[60%] right-6 w-6 h-6 bg-[#1e293b] rounded-full border-4 border-black"></div>
            </div>

            {/* Steps beneath the house */}
            <div className="absolute -bottom-16 w-64 flex flex-col items-center">
               <div className="w-full h-6 bg-[#1e293b] border-2 border-black"></div>
               <div className="w-[115%] h-6 bg-[#1e293b] border-2 border-black"></div>
               <div className="w-[130%] h-6 bg-[#1e293b] border-2 border-black"></div>
            </div>
          </div>

          {/* Bushes / Foregound details at the bottom */}
          <div className="absolute bottom-0 w-full h-[18%] bg-[#050505] z-40 flex flex-col items-center justify-end">
             {/* Bottom descriptive text */}
             <div className="max-w-3xl text-center px-10 pb-12">
                <p className="text-white text-3xl font-mono leading-tight tracking-tight drop-shadow-md">
                  Clickbait nedir? Çekici ama yanıltıcı başlıklar ve görsellerle tıklatarak insanları bağlantıya çekmeye çalışan teknik.
                </p>
             </div>
          </div>

          {/* Random floating pixel dust */}
          <div className="absolute inset-0 pointer-events-none z-0 overflow-hidden">
            {Array.from({ length: 40 }).map((_, i) => (
              <div key={i} className="absolute w-1 h-1 bg-white/30 rounded-full animate-pulse" 
                   style={{ 
                     top: `${Math.random() * 100}%`, 
                     left: `${Math.random() * 100}%`,
                     animationDelay: `${Math.random() * 8}s`,
                     animationDuration: `${2 + Math.random() * 4}s`
                   }}></div>
            ))}
          </div>
        </div>

        {/* Retro scanline effect */}
        <div className="pointer-events-none absolute inset-0 z-[100] opacity-[0.08] bg-[linear-gradient(rgba(18,16,16,0)_50%,rgba(0,0,0,0.25)_50%),linear-gradient(90deg,rgba(255,0,0,0.06),rgba(0,255,0,0.02),rgba(0,0,255,0.06))] bg-[length:100%_4px,3px_100%]"></div>
      </div>
    );
  }

  if (gameState.screen === GameScreen.SEASON_SELECT) {
    return (
      <div className="w-full h-full bg-slate-950 flex flex-col items-center justify-center p-8">
        <h2 className="text-5xl text-blue-400 font-bold mb-12 uppercase tracking-widest">SEZON SEÇ</h2>
        <div className="flex gap-8">
          {[1, 2, 3].map(season => (
            <button
              key={season}
              onClick={() => selectSeason(season)}
              className="group bg-slate-900 border-4 border-slate-800 p-8 w-64 hover:border-blue-500 transition-all hover:scale-105 flex flex-col items-center"
            >
              <span className="text-6xl mb-4 group-hover:animate-bounce">
                {season === 1 ? '📧' : season === 2 ? '🕵️' : '💻'}
              </span>
              <h3 className="text-2xl text-white font-bold mb-2">Sezon {season}</h3>
              <p className="text-slate-400 text-sm">
                {season === 1 ? 'Temel Tehditler' : season === 2 ? 'Kurnaz Tuzaklar' : 'Gelişmiş Saldırılar'}
              </p>
            </button>
          ))}
        </div>
      </div>
    );
  }

  if (gameState.screen === GameScreen.LEVEL_INTRO) {
    return (
      <div className="w-full h-full bg-black flex flex-col items-center justify-center p-12">
        <div className="bg-slate-900 border-4 border-blue-900 p-10 max-w-3xl pixel-border">
          <h2 className="text-4xl text-blue-400 font-bold mb-6 uppercase">LEVEL {gameState.currentLevel}: {gameState.currentLevel === 1 ? 'BAŞLIYORUZ' : 'DEVAM EDİYORUZ'}</h2>
          <div className="space-y-4 text-xl text-slate-300 font-mono leading-relaxed mb-8">
            <p>
              <span className="text-yellow-500 font-bold">CLICKBAIT:</span> Bazı duyguları fazla abartarak ilginizi çekme odaklı olan başlıklara sahip mesajlardır. Tıklandığında virüsle karşılaşılabilir veya bundaki amaç sadece tıklama kasmak olabilir.
            </p>
            <p>
              <span className="text-green-500 font-bold">KURAL 1:</span> Tıkladığın <span className="text-green-400 italic">Güvenli</span> başlıklar sana <span className="text-green-400">$1000</span> kazandırır.
            </p>
            <p>
              <span className="text-red-500 font-bold">KURAL 2:</span> Tıkladığın <span className="text-red-400 italic">Clickbait</span> başlıklar dolandırıcının sana ulaşma hakkını doldurur.
            </p>
          </div>
          <button 
            onClick={startGame}
            className="w-full bg-blue-600 hover:bg-blue-500 text-white py-4 text-2xl font-black uppercase tracking-widest"
          >
            ANLADIM, BAŞLA!
          </button>
        </div>
      </div>
    );
  }

  if (gameState.isGameOver) {
    return (
      <div className="fixed inset-0 bg-red-950 flex flex-col items-center justify-center p-10 z-[200]">
        <h1 className="text-8xl text-white font-black italic tracking-tighter mb-4 glitch">KAYBETTİN!</h1>
        <p className="text-2xl text-red-300 mb-8 max-w-lg text-center font-mono">
          Dolandırıcı sistemine sızdı ve kapını kırdı. Artık çok geç...
        </p>
        <div className="flex gap-4">
          <button 
            onClick={restartSeason}
            className="bg-white text-red-900 px-10 py-4 text-3xl font-black pixel-border hover:bg-red-100 transition-colors"
          >
            SEZONU TEKRARLA
          </button>
          <button 
            onClick={() => setGameState(prev => ({ ...prev, screen: GameScreen.MENU, isGameOver: false }))}
            className="bg-slate-800 text-white px-10 py-4 text-3xl font-black pixel-border hover:bg-slate-700 transition-colors"
          >
            ANA MENÜ
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="w-screen h-screen flex flex-col bg-black overflow-hidden select-none">
      <div className="h-12 bg-slate-900 border-b-4 border-black flex items-center justify-between px-6 z-20">
        <div className="flex gap-4 items-center">
          <span className="text-blue-400 font-bold text-xl uppercase tracking-tighter">S{gameState.selectedSeason} - BÖLÜM {gameState.currentLevel}</span>
          <span className="text-slate-500 text-sm">|</span>
          <span className="text-slate-300 text-sm italic">{gameState.lastActionMessage}</span>
        </div>
      </div>

      <div className="flex-1 flex overflow-hidden">
        <div className="w-[75%] h-full">
          <House 
            reachProgress={gameState.reachProgress} 
            hasShutters={gameState.upgrades.shutters > 0}
          />
        </div>
        <div className="w-[25%] h-full border-l-4 border-black">
          <Phone 
            balance={gameState.balance}
            lives={gameState.lives}
            emails={gameState.emails}
            onEmailClick={handleEmailClick}
            onSkipLevel={handleSkipLevel}
            hasAntivirus={gameState.upgrades.antivirus > 0}
            isGlitching={isGlitching}
          />
        </div>
      </div>

      {gameState.showShop && (
        <Shop 
          gameState={gameState} 
          onPurchase={handlePurchase} 
          onNextLevel={startNextLevel} 
        />
      )}

      <div className="pointer-events-none fixed inset-0 z-[1000] opacity-[0.03] bg-[linear-gradient(rgba(18,16,16,0)_50%,rgba(0,0,0,0.25)_50%),linear-gradient(90deg,rgba(255,0,0,0.06),rgba(0,255,0,0.02),rgba(0,0,255,0.06))] bg-[length:100%_2px,3px_100%]"></div>
    </div>
  );
};

export default App;
