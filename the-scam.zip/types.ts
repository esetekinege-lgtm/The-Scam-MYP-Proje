
export enum EmailType {
  SAFE = 'SAFE',
  PHISHING = 'PHISHING'
}

export enum GameScreen {
  MENU = 'MENU',
  SEASON_SELECT = 'SEASON_SELECT',
  LEVEL_INTRO = 'LEVEL_INTRO',
  GAME = 'GAME'
}

export interface Email {
  id: string;
  sender: string;
  subject: string;
  content: string;
  type: EmailType;
  icon: string;
  isRead: boolean;
}

export interface Upgrade {
  id: string;
  name: string;
  description: string;
  cost: number;
  level: number;
  maxLevel: number;
}

export interface GameState {
  screen: GameScreen;
  isLoading: boolean;
  balance: number;
  reachProgress: number;
  lives: number;
  currentLevel: number;
  selectedSeason: number;
  emails: Email[];
  upgrades: {
    doorChain: number;
    antivirus: number;
    shutters: number;
    siren: number;
  };
  isGameOver: boolean;
  isVictory: boolean;
  showShop: boolean;
  lastActionMessage: string;
}
